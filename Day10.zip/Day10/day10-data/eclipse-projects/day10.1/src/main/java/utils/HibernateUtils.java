package utils;

import org.hibernate.*;//HB
import org.hibernate.cfg.Configuration;//config HB

public class HibernateUtils {
	private static SessionFactory factory;
  //how to ensure creation of singleton instance of the session factory ? : EAGER singleton pattern
	static {
		System.out.println("in static init block");
		factory=new Configuration().configure().buildSessionFactory();
	}
	//getter for SF (SessionFactory)
	public static SessionFactory getFactory() {
		return factory;
	}
	
}
