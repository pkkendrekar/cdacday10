package tester;
import static utils.HibernateUtils.getFactory;
//in HB Utils pkg is utils and HButils Is a class get factory is a method

import org.hibernate.SessionFactory;

public class TestHibernate {

	public static void main(String[] args) {
		try(SessionFactory sf=getFactory())
		{
			System.out.println("Hibernate is up n running !!!!!!"+sf);
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

}
